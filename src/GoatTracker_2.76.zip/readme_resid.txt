This is reSID, a reverse engineered software emulation of the MOS6581 SID
(Sound Interface Device). This chip was used in the Commodore 64 computer.

reSID is free software. See the file COPYING for copying permission.

reSID is a C++ library containing a complete emulation of the SID chip.
This library can be linked into programs emulating the MOS6510 MPU to
play music made for the Commodore 64 computer. reSID has been successfully
linked into VICE, a full-fledged Commodore 64 emulator, and SIDPLAY, a
popular SID tune player. The VICE home page is:
http://www.cs.cmu.edu/~dsladic/vice/
A patch for SIDPLAY can be found on the SIDPLAY home page:
http://www.geocities.com/SiliconValley/Lakes/5147/

Various SID emulators exist, however reSID should still be of great
interest to Commodore 64 nostalgics. The emulator engine is cycle-based,
emulating the internal operations of the SID chip. SID's audio filter is
modeled as an actual two-integrator-loop biquadratic filter circuit.
The engine has been developed based on available information on SID, sampling
of the OSC3 and ENV3 registers, filter theory, and meticulous testing.
In short, a scientific approach has been taken to model the SID chip as
accurately as possible.

To our knowledge reSID is by far the most accurate SID emulator ever created.
This comes at a price; what is considered a fairly fast CPU at the time of
this writing is needed to run the emulator.
